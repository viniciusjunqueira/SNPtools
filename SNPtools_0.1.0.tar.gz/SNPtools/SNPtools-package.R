#' SNPtools
#'
#' Ferramentas S4 para Leitura e Organização de Dados Genéticos.
#'
#' @docType package
#' @name SNPtools
#' @author
#' Vinícius Junqueira \email{junqueiravinicius@hotmail.com}
#'
#' @keywords internal
"_PACKAGE"
